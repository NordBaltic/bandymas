import React from 'react';

const Navbar = () => {
    return (
        <nav>
            <h1>Navbar</h1>
        </nav>
    );
};

export default Navbar;
