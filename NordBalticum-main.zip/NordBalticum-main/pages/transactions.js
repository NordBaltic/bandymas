import React from 'react';

const Transactions = () => {
    return (
        <div style={{ textAlign: 'center', padding: '50px' }}>
            <h1>Transactions</h1>
            <p>This page will show user transactions.</p>
        </div>
    );
};

export default Transactions;
