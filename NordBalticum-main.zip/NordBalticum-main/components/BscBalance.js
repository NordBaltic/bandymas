import React from 'react';

const BscBalance = () => {
  return <div>BSC Balance Placeholder</div>;
};

export default BscBalance;
